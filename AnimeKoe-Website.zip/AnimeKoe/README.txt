# AnimeKoe — Panduan Hosting

AnimeKoe adalah frontend forum diskusi anime. Login Google memakai Firebase Authentication (OAuth), sedangkan post dan komentar disimpan di Cloud Firestore.

## 1. Buat proyek Firebase
1. Buka https://console.firebase.google.com/ lalu buat proyek.
2. Tambahkan aplikasi Web (ikon `</>`), lalu salin konfigurasi Firebase.
3. Buka `index.html`, cari bagian `const firebaseConfig`, lalu ganti seluruh nilai `GANTI_DENGAN_...` dengan konfigurasi proyekmu.
4. Di Firebase Console, buka Authentication → Sign-in method → aktifkan **Google**.
5. Pada Authentication → Settings → Authorized domains, tambahkan domain hosting kamu (misalnya domain Netlify/Vercel atau domain sendiri).

## 2. Aktifkan Firestore
1. Buka Firestore Database → Create database.
2. Pilih lokasi database yang paling dekat dengan mayoritas pengguna.
3. Buka tab Rules, lalu salin isi file `firestore.rules` dan klik Publish.

## 3. Hosting
Unggah `index.html` ke hosting static seperti Netlify, Vercel, GitHub Pages, atau hosting web biasa. Firebase SDK dimuat dari CDN, jadi halaman memerlukan koneksi internet. Untuk domain produksi, gunakan HTTPS.

## 4. Catatan keamanan dan produksi
- Jangan pernah meminta password Google pengguna. Tombol masuk memakai halaman OAuth Google resmi.
- Firebase Web API key memang berada di frontend; keamanan data harus ditegakkan melalui Firestore Security Rules, bukan dengan menyembunyikan API key.
- Aturan yang disertakan cocok untuk prototipe komunitas kecil. Untuk produksi publik, sebaiknya pindahkan pembuatan komentar dan increment `commentCount` ke Cloud Functions agar jumlah komentar tidak bisa dimanipulasi melalui update langsung.
- Tambahkan moderasi/report, rate limiting (misalnya App Check + backend), kebijakan privasi, syarat penggunaan, serta mekanisme penghapusan akun/data sebelum membuka komunitas untuk umum.
- Jangan menyimpan email atau informasi pribadi yang tidak diperlukan. Profil yang ditampilkan hanya nama dan foto publik dari profil Google.
- Firestore Rules tidak bisa membatasi spam berdasarkan frekuensi dengan baik; gunakan backend/rate limit untuk skala publik.

## Fitur saat ini
- Tampilan responsif desktop dan mobile.
- Login/logout Google.
- Buat diskusi berdasarkan kategori.
- Feed terbaru dan pencarian teks.
- Komentar real-time.
- Validasi input dasar dan escaping HTML untuk mencegah injeksi markup.

## Struktur
- `index.html` — seluruh frontend (HTML, CSS, JavaScript).
- `firestore.rules` — aturan akses Firestore.
